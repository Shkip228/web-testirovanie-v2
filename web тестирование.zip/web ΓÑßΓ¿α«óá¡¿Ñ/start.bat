@echo off
chcp 65001 >nul
echo ========================================
echo   Запуск сервера РУ-ДАТА
echo   Журнал + Проверка
echo ========================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python не установлен.
    echo [!] Скачайте с https://python.org
    pause
    exit /b
)
echo [*] Python найден:
python --version
echo.
if not exist "templates" mkdir templates
echo [*] Запуск сервера...
echo [*] Главная:   http://127.0.0.1:5000
echo [*] Журнал:    http://127.0.0.1:5000/journal
echo [*] Проверка:  http://127.0.0.1:5000/checker
echo.
python server.py
pause