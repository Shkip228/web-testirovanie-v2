#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Единый сервер: Журнал + Проверка
Минималистичный дизайн, real-time синхронизация через SSE
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import sqlite3
import json
import os
import time
import threading
from datetime import datetime
from urllib.parse import urlparse, parse_qs

DB_PATH = 'reports.db'
TEMPLATES_DIR = 'templates'
PORT = 5000

# ============ SSE МЕНЕДЖЕР ============
class SSEManager:
    def __init__(self):
        self.clients = []
        self.lock = threading.Lock()

    def add_client(self, wfile):
        with self.lock:
            self.clients.append(wfile)

    def remove_client(self, wfile):
        with self.lock:
            if wfile in self.clients:
                self.clients.remove(wfile)

    def broadcast(self, event_type, data):
        with self.lock:
            dead = []
            msg = f"event: {event_type}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"
            encoded = msg.encode('utf-8')
            for client in self.clients:
                try:
                    client.write(encoded)
                    client.flush()
                except Exception:
                    dead.append(client)
            for d in dead:
                self.clients.remove(d)

sse = SSEManager()

# ============ БД ============
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS workers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        position TEXT DEFAULT '',
        department TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        worker_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'present',
        note TEXT DEFAULT '',
        UNIQUE(worker_id, date),
        FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        worker_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        description TEXT NOT NULL,
        hours REAL DEFAULT 0,
        status TEXT DEFAULT 'done',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL UNIQUE,
        score INTEGER DEFAULT 0,
        quality TEXT DEFAULT 'pending',
        payment REAL DEFAULT 0,
        comment TEXT DEFAULT '',
        checked_by TEXT DEFAULT 'admin',
        checked_at TEXT,
        status TEXT DEFAULT 'pending',
        FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    )''')
    conn.commit()
    conn.close()

# ============ СЕРВЕР ============
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {args[0]}")

    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))

    def send_html(self, html):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

    def read_json_body(self):
        length = int(self.headers.get('Content-Length', 0))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length).decode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path == '/':
            self._serve_template('index.html')
        elif path == '/journal':
            self._serve_template('journal.html')
        elif path == '/checker':
            self._serve_template('checker.html')
        elif path == '/api/events':
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Connection', 'keep-alive')
            self.end_headers()
            sse.add_client(self.wfile)
            try:
                while True:
                    time.sleep(15)
                    self.wfile.write(b": heartbeat\n\n")
                    self.wfile.flush()
            except Exception:
                sse.remove_client(self.wfile)
        elif path == '/api/health':
            self.send_json({'status': 'ok', 'time': datetime.now().isoformat()})
        elif path == '/api/workers':
            conn = get_db()
            rows = conn.execute('SELECT * FROM workers ORDER BY name').fetchall()
            conn.close()
            self.send_json([dict(r) for r in rows])
        elif path == '/api/attendance':
            wid = qs.get('worker_id', [None])[0]
            year = qs.get('year', [str(datetime.now().year)])[0]
            month = qs.get('month', [str(datetime.now().month)])[0]
            if not wid:
                self.send_json({'error': 'worker_id required'}, 400)
                return
            conn = get_db()
            rows = conn.execute(
                'SELECT * FROM attendance WHERE worker_id=? AND strftime("%Y",date)=? AND strftime("%m",date)=? ORDER BY date',
                (wid, year, month.zfill(2))
            ).fetchall()
            conn.close()
            self.send_json([dict(r) for r in rows])
        elif path == '/api/tasks':
            wid = qs.get('worker_id', [None])[0]
            conn = get_db()
            if wid:
                rows = conn.execute(
                    'SELECT t.*, w.name as worker_name FROM tasks t JOIN workers w ON t.worker_id=w.id WHERE t.worker_id=? ORDER BY t.date DESC',
                    (wid,)
                ).fetchall()
            else:
                rows = conn.execute(
                    'SELECT t.*, w.name as worker_name FROM tasks t JOIN workers w ON t.worker_id=w.id ORDER BY t.date DESC'
                ).fetchall()
            conn.close()
            self.send_json([dict(r) for r in rows])
        elif path == '/api/tasks-for-review':
            status_filter = qs.get('status', [None])[0]
            conn = get_db()
            sql = '''SELECT t.*, w.name as worker_name, w.position, w.department,
                     r.id as review_id, r.score, r.quality, r.payment,
                     r.comment as review_comment, r.checked_by, r.checked_at,
                     r.status as review_status
                     FROM tasks t
                     JOIN workers w ON t.worker_id = w.id
                     LEFT JOIN reviews r ON r.task_id = t.id'''
            params = []
            if status_filter == 'pending':
                sql += ' WHERE r.status IS NULL OR r.status = "pending"'
            elif status_filter == 'done':
                sql += ' WHERE r.status IS NOT NULL AND r.status != "pending"'
            sql += ' ORDER BY t.date DESC'
            rows = conn.execute(sql, params).fetchall()
            conn.close()
            self.send_json([dict(r) for r in rows])
        elif path == '/api/stats':
            year = qs.get('year', [str(datetime.now().year)])[0]
            conn = get_db()
            workers_count = conn.execute('SELECT COUNT(*) FROM workers').fetchone()[0]
            tasks_count = conn.execute('SELECT COUNT(*) FROM tasks WHERE strftime("%Y",date)=?', (year,)).fetchone()[0]
            reviewed = conn.execute('''SELECT COUNT(*) FROM reviews r JOIN tasks t ON r.task_id=t.id
                                       WHERE strftime("%Y",t.date)=? AND r.status!="pending"''', (year,)).fetchone()[0]
            pending = conn.execute('''SELECT COUNT(*) FROM tasks t LEFT JOIN reviews r ON r.task_id=t.id
                                      WHERE strftime("%Y",t.date)=? AND (r.status IS NULL OR r.status="pending")''', (year,)).fetchone()[0]
            total_payment = conn.execute('''SELECT COALESCE(SUM(r.payment),0) FROM reviews r
                                            JOIN tasks t ON r.task_id=t.id WHERE strftime("%Y",t.date)=?''', (year,)).fetchone()[0]
            conn.close()
            self.send_json({
                'workers_count': workers_count,
                'tasks_count': tasks_count,
                'reviewed': reviewed,
                'pending': pending,
                'total_payment': total_payment
            })
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == '/api/workers':
            try:
                data = self.read_json_body()
                if not data.get('name'):
                    self.send_json({'error': 'ФИО обязательно'}, 400)
                    return
                conn = get_db()
                c = conn.cursor()
                c.execute('INSERT INTO workers (name,position,department) VALUES (?,?,?)',
                          (data['name'], data.get('position',''), data.get('department','')))
                conn.commit()
                w = conn.execute('SELECT * FROM workers WHERE id=?', (c.lastrowid,)).fetchone()
                conn.close()
                sse.broadcast('update', {'type': 'workers'})
                self.send_json(dict(w), 201)
            except Exception as e:
                self.send_json({'error': str(e)}, 500)

        elif path == '/api/attendance':
            try:
                data = self.read_json_body()
                conn = get_db()
                conn.execute('''INSERT INTO attendance (worker_id,date,status,note) VALUES (?,?,?,?)
                                ON CONFLICT(worker_id,date) DO UPDATE SET status=excluded.status, note=excluded.note''',
                             (data['worker_id'], data['date'], data['status'], data.get('note','')))
                conn.commit()
                conn.close()
                sse.broadcast('update', {'type': 'attendance'})
                self.send_json({'ok': True})
            except Exception as e:
                self.send_json({'error': str(e)}, 500)

        elif path == '/api/tasks':
            try:
                data = self.read_json_body()
                if not data.get('description'):
                    self.send_json({'error': 'Описание обязательно'}, 400)
                    return
                conn = get_db()
                c = conn.cursor()
                c.execute('INSERT INTO tasks (worker_id,date,description,hours,status) VALUES (?,?,?,?,?)',
                          (data['worker_id'], data.get('date', datetime.now().strftime('%Y-%m-%d')),
                           data['description'], data.get('hours', 0), data.get('status', 'done')))
                conn.commit()
                conn.close()
                sse.broadcast('update', {'type': 'tasks'})
                self.send_json({'ok': True, 'id': c.lastrowid}, 201)
            except Exception as e:
                self.send_json({'error': str(e)}, 500)

        elif path == '/api/reviews':
            try:
                data = self.read_json_body()
                conn = get_db()
                conn.execute('''INSERT INTO reviews (task_id,score,quality,payment,comment,checked_by,checked_at,status)
                                VALUES (?,?,?,?,?,?,?,?)
                                ON CONFLICT(task_id) DO UPDATE SET
                                  score=excluded.score, quality=excluded.quality, payment=excluded.payment,
                                  comment=excluded.comment, checked_by=excluded.checked_by,
                                  checked_at=excluded.checked_at, status=excluded.status''',
                             (data['task_id'], data.get('score',0), data.get('quality','pending'),
                              data.get('payment',0), data.get('comment',''),
                              data.get('checked_by','admin'),
                              datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                              data.get('status','pending')))
                conn.commit()
                conn.close()
                sse.broadcast('update', {'type': 'reviews'})
                self.send_json({'ok': True})
            except Exception as e:
                self.send_json({'error': str(e)}, 500)
        else:
            self.send_response(404)
            self.end_headers()

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith('/api/workers/'):
            try:
                wid = int(path.split('/')[-1])
                conn = get_db()
                conn.execute('DELETE FROM workers WHERE id=?', (wid,))
                conn.commit()
                conn.close()
                sse.broadcast('update', {'type': 'workers'})
                self.send_json({'ok': True})
            except Exception:
                self.send_json({'error': 'Invalid'}, 400)

        elif path.startswith('/api/tasks/'):
            try:
                tid = int(path.split('/')[-1])
                conn = get_db()
                conn.execute('DELETE FROM reviews WHERE task_id=?', (tid,))
                conn.execute('DELETE FROM tasks WHERE id=?', (tid,))
                conn.commit()
                conn.close()
                sse.broadcast('update', {'type': 'tasks'})
                self.send_json({'ok': True})
            except Exception:
                self.send_json({'error': 'Invalid'}, 400)
        else:
            self.send_response(404)
            self.end_headers()

    def _serve_template(self, filename):
        try:
            with open(os.path.join(TEMPLATES_DIR, filename), 'r', encoding='utf-8') as f:
                self.send_html(f.read())
        except FileNotFoundError:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(f'{filename} not found'.encode())

if __name__ == '__main__':
    if not os.path.exists(TEMPLATES_DIR):
        os.makedirs(TEMPLATES_DIR)
    init_db()
    server = ThreadedHTTPServer(('0.0.0.0', PORT), Handler)
    print("=" * 55)
    print("  СЕРВЕР ЗАПУЩЕН (Журнал + Проверка)")
    print("=" * 55)
    print(f"  Главная:   http://127.0.0.1:{PORT}")
    print(f"  Журнал:    http://127.0.0.1:{PORT}/journal")
    print(f"  Проверка:  http://127.0.0.1:{PORT}/checker")
    print("=" * 55)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановлен")
        server.server_close()